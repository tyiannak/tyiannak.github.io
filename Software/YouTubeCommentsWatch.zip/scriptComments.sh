# get the all comments link:
videoLink=${1##*watch?}
allCommentsLink="http://www.youtube.com/comment_servlet?all_comments&"$videoLink

#echo "Video ad: $videoLink "
#echo "Comm  ad: $allCommentsLink"

# download the main html doc:
clear;
echo "Downloading video information...please wait...";
wget $1 -q -O videoURLmain
# download the "all comments" doc:
clear;
echo "Downloading user comments...please wait...";
wget $allCommentsLink -q -O videoURLcomments
clear;

# run the text analysis tool:
./youTubeTextAnalysisMain stopWords videoURLmain videoURLcomments 0
