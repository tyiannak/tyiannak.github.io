function createXML(fileName, Duration, T1, T2, Label);

% creates the XML file given the total wav file duration and the 
% time of the 1st audio segment

docNode = com.mathworks.xml.XMLUtils.createDocument('Mpeg7'); 
docRootNode = docNode.getDocumentElement; 

%for i=1:length(arrData1),
    % create nodes..    
    Descr = docNode.createElement('Description');
    MultCont = docNode.createElement('MultimediaContent');
    Audio = docNode.createElement('Audio');
    MediaTime = docNode.createElement('MediaTime');
    TemporalDecomposition  = docNode.createElement('TemporalDecomposition');
    
    AudioSegment  = docNode.createElement('AudioSegment');
    TextAnnotation  = docNode.createElement('TextAnnotation');
    FreeTextAnnotation  = docNode.createElement('FreeTextAnnotation');
    MediaTime2  = docNode.createElement('MediaTime');
    MediaTimePoint2 = docNode.createElement('MediaTimePoint');
    MediaDuration2 = docNode.createElement('MediaDuration');
    
    
    MediaTimePoint = docNode.createElement('MediaTimePoint');
    MediaDuration = docNode.createElement('MediaDuration');
    


    % put data in nodes..
    MediaTimePoint.appendChild(docNode.createTextNode('0.0'));
    MediaDuration.appendChild(docNode.createTextNode(sprintf('%.1f',Duration)));
    
    MediaTimePoint2.appendChild(docNode.createTextNode(sprintf('%.1f',T1)));
    MediaDuration2.appendChild(docNode.createTextNode(sprintf('%.1f',T2-T1)));
    FreeTextAnnotation.appendChild(docNode.createTextNode(sprintf('%s',Label)));


    % put nodes in the correct positions..
      MediaTime.appendChild(MediaTimePoint);
      MediaTime.appendChild(MediaDuration);
	Audio.appendChild(MediaTime);
      Audio.appendChild(TemporalDecomposition);
      TemporalDecomposition.appendChild(AudioSegment);
      AudioSegment.appendChild(TextAnnotation);
        TextAnnotation.appendChild(FreeTextAnnotation);
      AudioSegment.appendChild(MediaTime2);
      MediaTime2.appendChild(MediaTimePoint2);
      MediaTime2.appendChild(MediaDuration2);
    MultCont.appendChild(Audio);
    Descr.appendChild(MultCont);
    docRootNode.appendChild(Descr);
%end 

xmlwrite(fileName, docNode);
