function [numOfSegments, limits, labels] = writeToWavFile(fileName, Flags, win, classNames, DO_NOT_WRITE);

% same as in 'violenceClassification_v4'....

[aa,fs] = wavread(fileName,'size');

preFlag = 1;
curFlag = 1;
numOfSegments = 0;

curVal = Flags(curFlag);

W = waitbar(0,'Writing segments to files.');

while (curFlag<length(Flags))
    stop = 0;
    preFlag = curFlag;
    preVal = curVal;
    while (stop==0)
        curFlag = curFlag + 1;
        tempVal = Flags(curFlag);
        if ((tempVal~=curVal) | (curFlag==length(Flags))) % stop
            numOfSegments = numOfSegments + 1;
            stop = 1;
            curSegment = curVal;
            curVal = Flags(curFlag);
        end            
    end
    
    if (DO_NOT_WRITE==0)
        xtemp = wavread(fileName, [round((preFlag-1)*win*fs+1)  round((curFlag-1)*win*fs+1)]);    
    end
    limits(1, numOfSegments) = round((preFlag-1)*win*fs+1);
    limits(2, numOfSegments) = round((curFlag-1)*win*fs+1);
    labels(numOfSegments) = preVal;
            
    
    if (preVal~=0)
        waitbar(curFlag / length(Flags), W, sprintf('%5.1f%%: %s',100*curFlag / length(Flags), classNames{preVal}));
        tempName = sprintf('%s_%.3d_%s.wav',fileName,numOfSegments,classNames{preVal});        
    else
        waitbar(curFlag / length(Flags), W, sprintf('%5.1f%%: unclassified',100*curFlag / length(Flags)));
        tempName = sprintf('%s_%.3d_unclassified.wav',fileName,numOfSegments);        
    end
    
    
    % fprintf('Writing file: %s  : %6.2f-%6.2f\n',tempName,(preFlag-1)*win,(curFlag-1)*win);
    
    if (curSegment==0)
        %fprintf('   :  SPEECH\n');
    else
        %fprintf('   :  MUSIC\n');
    end
    if (DO_NOT_WRITE==0)
        wavwrite(xtemp, fs, 16, tempName);   
    end
end
close(W);