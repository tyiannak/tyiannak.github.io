docNode = com.mathworks.xml.XMLUtils.createDocument('Node1'); 

docRootNode = docNode.getDocumentElement; 
arrData1 = [1 2 3 4 5];
arrData2 = [6 4 3 4 5];
for i=1:length(arrData1),
    % create nodes..
    elPar = docNode.createElement('DataParent');
    elData1 = docNode.createElement('Data1');
    elData2 = docNode.createElement('Data2');

    % put data in nodes..
    elData1.appendChild(docNode.createTextNode(sprintf('%f', arrData1(i))));
    elData2.appendChild(docNode.createTextNode(sprintf('%f', arrData2(i))));

    % put nodes in the correct positions..
    elPar.appendChild(elData1);
    elPar.appendChild(elData2);
    docRootNode.appendChild(elPar);
end 

datFile = 'aaa';
[filename, pathname] = uiputfile(...
sprintf('%s.xml', datFile), 'Save XML file as');

% Save the XML document.
% xmlFileName = [dataOutFile,'.xml'];
xmlFileName = fullfile(pathname, filename);
xmlwrite(xmlFileName,docNode);
