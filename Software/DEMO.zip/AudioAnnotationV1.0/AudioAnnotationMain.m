function varargout = AudioAnnotationMain(varargin)
% AUDIOANNOTATIONMAIN M-file for AudioAnnotationMain.fig
%      AUDIOANNOTATIONMAIN, by itself, creates a new AUDIOANNOTATIONMAIN or raises the existing
%      singleton*.
%
%      H = AUDIOANNOTATIONMAIN returns the handle to a new AUDIOANNOTATIONMAIN or the handle to
%      the existing singleton*.
%
%      AUDIOANNOTATIONMAIN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in AUDIOANNOTATIONMAIN.M with the given input arguments.
%
%      AUDIOANNOTATIONMAIN('Property','Value',...) creates a new AUDIOANNOTATIONMAIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before AudioAnnotationMain_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to AudioAnnotationMain_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help AudioAnnotationMain

% Last Modified by GUIDE v2.5 09-Sep-2007 18:25:34

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @AudioAnnotationMain_OpeningFcn, ...
                   'gui_OutputFcn',  @AudioAnnotationMain_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before AudioAnnotationMain is made visible.
function AudioAnnotationMain_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to AudioAnnotationMain (see VARARGIN)

% Choose default command line output for AudioAnnotationMain
warning off;

handles.output = hObject;
handles.T1 = 0.0;
handles.fileName = '';

% set classNames:

% YOU CAN CHANGE THE FOLLOWING FIELDS AND COMBO BOXES WILL CHANGE RESPECTIVELY:
% 
handles.classNames = {'Music','Speech Neutral','Speech Anger','Speech Fear','Others1','Others2','Others3','Shots','Explosions','Fights','Screams'};
handles.FeatureStrs = {'ShortTimeEnergy', 'ZCR'};
handles.StatisticsStrs = {'mean', 'median','std','max','stdbymean'};
set(handles.popSegmentGenre, 'String', handles.classNames);
set(handles.popupmenuFeature, 'String', handles.FeatureStrs);
set(handles.popupmenuStatistic, 'String', handles.StatisticsStrs);


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes AudioAnnotationMain wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = AudioAnnotationMain_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushChooseFile.
function pushChooseFile_Callback(hObject, eventdata, handles)
% hObject    handle to pushChooseFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% LOAD DIALOG BOX FOR WAV FILE SELECTION:
[FileName,PathName] = uigetfile({'*.wav'},'Load Wav File');
if (FileName==0) % if cancel pressed:
    return
end

fileName = sprintf('%s\\%s',PathName,FileName);
[a, fs] = wavread(fileName,'size');
nSamples = a(1);
nChannels = a(2);
fileTime = nSamples / fs;

% compute file time (minutes, seconds, dseconds):
fileHours = floor(fileTime/3600);
fileMinutes = floor(fileTime/60);
fileSeconds = mod(fileTime, 60);
fileDecSeconds = round(10*(fileSeconds - floor(fileSeconds)));
fileSeconds = floor(fileSeconds);

% display file info:
set(handles.infoFile, 'String', fileName);
set(handles.info1, 'String', sprintf('%d Hz',fs));
set(handles.info2, 'String', sprintf('%.2d:%.2d:%.2d.%d',fileHours,fileMinutes, fileSeconds, fileDecSeconds));
set(handles.info3, 'String', sprintf('%d',nChannels));

% check if wav file exists:
fp = fopen(fileName, 'r');
if (fp>0)
    % keep fileName:
    handles.Fs = fs;
    handles.fileName = fileName;
    handles.fileTime = fileTime;    
    fclose(fp);
else
    msgbox('File Not Found!','File not found','error'); 
    return;
end

Step1 = 1 / floor(fileTime*10);
set(handles.sliderT1, 'Max', floor(fileTime*10));
set(handles.sliderT1, 'SliderStep', [Step1 Step1*10]);
set(handles.sliderT1, 'Value', 0);
set(handles.sliderWindow, 'Value', get(handles.sliderWindow,'Max') / 4);
handles.Window = (get(handles.sliderWindow,'Max') / 4)/10;

windowPos = get(handles.sliderWindow,'Value')+1;

handles = updateSegmentLimitsFromSliders(handles, windowPos);


[T1,T2] = getTimeFields(handles);


set(handles.slider5, 'Max', 5.0);
set(handles.slider5, 'Min', 0.5);
set(handles.slider5, 'Value', 1.0);
handles.Volume = 1.0;


% load the real flags for the first time:

matFileName = [handles.fileName(1:end-4) '_labels.mat'];
fp = fopen(matFileName,'r');
if (fp<0)
    % file DOES NOT EXIST-->CREATE:
    flagsReal = zeros(round(handles.fileTime*10), 1);    
else
    % file EXISTS-->UPDATE:        
    fclose(fp); 
    load([handles.fileName(1:end-4) '_labels.mat']);
end
     

% find segment boundaries from flags:
[numOfSegments, limits, labels] = writeToWavFile(handles.fileName, flagsReal, 0.10, handles.classNames, 1);

handles.limits = limits;
handles.flagsReal = flagsReal;
handles.labels = labels;

% plot the Histogram:
plotHist(handles);
displaySignal(handles, T1, T2);

guidata(hObject, handles);



function infoFile_Callback(hObject, eventdata, handles)
% hObject    handle to infoFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of infoFile as text
%        str2double(get(hObject,'String')) returns contents of infoFile as a double


% --- Executes during object creation, after setting all properties.
function infoFile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to infoFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end





function info1_Callback(hObject, eventdata, handles)
% hObject    handle to info1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of info1 as text
%        str2double(get(hObject,'String')) returns contents of info1 as a double


% --- Executes during object creation, after setting all properties.
function info1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to info1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function info2_Callback(hObject, eventdata, handles)
% hObject    handle to info2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of info2 as text
%        str2double(get(hObject,'String')) returns contents of info2 as a double


% --- Executes during object creation, after setting all properties.
function info2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to info2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function info3_Callback(hObject, eventdata, handles)
% hObject    handle to info3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of info3 as text
%        str2double(get(hObject,'String')) returns contents of info3 as a double


% --- Executes during object creation, after setting all properties.
function info3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to info3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end





function editHours1_Callback(hObject, eventdata, handles)
% hObject    handle to editHours1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editHours1 as text
%        str2double(get(hObject,'String')) returns contents of editHours1 as a double


% --- Executes during object creation, after setting all properties.
function editHours1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editHours1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editTime2_Callback(hObject, eventdata, handles)
% hObject    handle to editTime2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editTime2 as text
%        str2double(get(hObject,'String')) returns contents of editTime2 as a double


% --- Executes during object creation, after setting all properties.
function editTime2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editTime2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on button press in pushUpdateFile.
function pushUpdateFile_Callback(hObject, eventdata, handles)
% hObject    handle to pushUpdateFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if (length(handles.fileName)>0)    
    [T1,T2] = getTimeFields(handles);
    xmlFileName = [handles.fileName(1:end-4) '_labels.xml'];
    Label = get(handles.popSegmentGenre, 'String');
    L = Label{get(handles.popSegmentGenre, 'Value')};
    LIndex = get(handles.popSegmentGenre,'Value');
    fp = fopen(xmlFileName,'r');
    if (fp<0)
        % file DOES NOT EXIST-->CREATE:
        flagsReal = zeros(round(handles.fileTime*10), 1);
        createXML(xmlFileName, handles.fileTime, T1, T2, L);
    else
        % file EXISTS-->UPDATE:        
        fclose(fp);            
        addXMLAudioSegment(xmlFileName, T1, T2, L);
        load([handles.fileName(1:end-4) '_labels.mat']);
    end
        
            
    % save the flags array in the .mat file:
    flagsReal(round(T1*10)+1: round(T2*10)) = LIndex;    
    save([handles.fileName(1:end-4) '_labels.mat'], 'flagsReal');
    
    [numOfSegments, limits, labels] = writeToWavFile(handles.fileName, flagsReal, 0.10, handles.classNames, 1);
    
    handles.flagsReal = flagsReal;
    handles.limits = limits;
    handles.labels = labels;
    
    %fp = fopen('','ab');
    
    % Update the Histogram:
    
    guidata(hObject, handles);
    plotHist(handles);
    displaySignal(handles, T1, T2);
    guidata(hObject, handles);

    if (T1>T2)  msgbox('Wrong segments limits.','Wrong limits','error'); end
else
    msgbox('No file is loaded!','No file','error'); return;
end



function editMinutes1_Callback(hObject, eventdata, handles)
% hObject    handle to editMinutes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editMinutes1 as text
%        str2double(get(hObject,'String')) returns contents of editMinutes1 as a double


% --- Executes during object creation, after setting all properties.
function editMinutes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editMinutes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editSeconds1_Callback(hObject, eventdata, handles)
% hObject    handle to editSeconds1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editSeconds1 as text
%        str2double(get(hObject,'String')) returns contents of editSeconds1 as a double


% --- Executes during object creation, after setting all properties.
function editSeconds1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editSeconds1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editDSeconds1_Callback(hObject, eventdata, handles)
% hObject    handle to editDSeconds1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editDSeconds1 as text
%        str2double(get(hObject,'String')) returns contents of editDSeconds1 as a double


% --- Executes during object creation, after setting all properties.
function editDSeconds1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editDSeconds1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editHours2_Callback(hObject, eventdata, handles)
% hObject    handle to editHours2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editHours2 as text
%        str2double(get(hObject,'String')) returns contents of editHours2 as a double


% --- Executes during object creation, after setting all properties.
function editHours2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editHours2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editMinutes2_Callback(hObject, eventdata, handles)
% hObject    handle to editMinutes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editMinutes2 as text
%        str2double(get(hObject,'String')) returns contents of editMinutes2 as a double


% --- Executes during object creation, after setting all properties.
function editMinutes2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editMinutes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editSeconds2_Callback(hObject, eventdata, handles)
% hObject    handle to editSeconds2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editSeconds2 as text
%        str2double(get(hObject,'String')) returns contents of editSeconds2 as a double


% --- Executes during object creation, after setting all properties.
function editSeconds2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editSeconds2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editDSeconds2_Callback(hObject, eventdata, handles)
% hObject    handle to editDSeconds2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editDSeconds2 as text
%        str2double(get(hObject,'String')) returns contents of editDSeconds2 as a double


% --- Executes during object creation, after setting all properties.
function editDSeconds2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editDSeconds2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popSegmentGenre.
function popSegmentGenre_Callback(hObject, eventdata, handles)
% hObject    handle to popSegmentGenre (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popSegmentGenre contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popSegmentGenre


% --- Executes during object creation, after setting all properties.
function popSegmentGenre_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popSegmentGenre (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% the following function returns the time (in seconds) of a specific
% duration given the hours, minutes, seconds and dseconds.
function D = time2Seconds(H, M, S, DS)
D = 3600 * H + 60 * M + S  + 0.10*DS;

function [T1,T2, H1, M1, S1, DS1, H2, M2, S2, DS2] = getTimeFields(handles)
% get the time fields (hours, minutes, seconds and dec-seconds) for T1:
H1 = str2num(get(handles.editHours1,'String'));
M1 = str2num(get(handles.editMinutes1,'String'));
S1 = str2num(get(handles.editSeconds1,'String'));
DS1 = str2num(get(handles.editDSeconds1,'String'));
% get the time fields (hours, minutes, seconds and dec-seconds) for T2:
H2 = str2num(get(handles.editHours2,'String'));
M2 = str2num(get(handles.editMinutes2,'String'));
S2 = str2num(get(handles.editSeconds2,'String'));
DS2 = str2num(get(handles.editDSeconds2,'String'));

% check if the given time fields are valid:
    
if ((isempty(H1)) | (H1<0)) msgbox('The hour text at T1 is incorrect!','Error - Hour of T1','error'); return; end
if ((isempty(H2)) | (H2<0)) msgbox('The hour text at T2 is incorrect!','Error - Hour of T2','error'); return; end
if ((isempty(M1)) | (M1<0) | (M1>=60)) msgbox('The minute text at T1 is incorrect!','Error - Minute of T1','error'); return; end
if ((isempty(M2)) | (M2<0) | (M2>=60)) msgbox('The minute text at T2 is incorrect!','Error - Minute of T2','error'); return; end
if ((isempty(S1)) | (S1<0) | (S1>=60)) msgbox('The seconds text at T1 is incorrect!','Error - Seconds of T1','error'); return; end
if ((isempty(S2)) | (S2<0) | (S2>=60)) msgbox('The seconds text at T2 is incorrect!','Error - Seconds of T2','error'); return; end
if ((isempty(DS1)) | (DS1<0) | (DS1>=10)) msgbox('The dec-seconds text at T1 is incorrect!','Error - Dec-Seconds of T1','error'); return; end
if ((isempty(DS2)) | (DS2<0) | (DS2>=10)) msgbox('The dec-seconds text at T2 is incorrect!','Error - Dec-Seconds of T2','error'); return; end

% check if T1 is < than T2:
T1 = time2Seconds(H1, M1, S1, DS1);
T2 = time2Seconds(H2, M2, S2, DS2);


% --- Executes on button press in pushPlaySound.
function pushPlaySound_Callback(hObject, eventdata, handles)
% hObject    handle to pushPlaySound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% check if fileName has been given:
if (length(handles.fileName)>0)
    [T1,T2] = getTimeFields(handles);
    if (T1>=T2)  msgbox('Wrong segments limits.','Wrong limits','error'); return; end    
    x = wavread(handles.fileName, round([T1*handles.Fs+1 T2*handles.Fs]));
    
    xtemp = handles.Volume * x;
    %sound(xtemp, handles.Fs);
    handles.playerY = audioplayer(xtemp', handles.Fs);
    play(handles.playerY);   
    guidata(hObject, handles);    
    

else
    msgbox('No file is loaded!','No file','error'); return; 
end



% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over pushPlaySound.
function pushPlaySound_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to pushPlaySound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --- Executes on slider movement.
function sliderT1_Callback(hObject, eventdata, handles)
% hObject    handle to sliderT1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

if (strcmp(handles.fileName,'')==1) return; end;

curPos = get(hObject,'Value');

Time = curPos / 10;

windowPos = get(handles.sliderWindow,'Value')+1;

TotalTimeTemp = Time + windowPos / 10;

% check if slider has been moved out of bounds:
if (TotalTimeTemp > handles.fileTime)
    % set slider to previous value:
    set(hObject, 'Value', 10 * handles.T1);
    return;
end

handles.T1 = Time;

% compute time (minutes, seconds, dseconds):
Hours = floor(Time/3600);
Minutes = floor(Time/60);
Seconds = mod(Time, 60);
DecSeconds = floor(10*(Seconds - floor(Seconds)));
Seconds = floor(Seconds);

set(handles.editHours1, 'String', sprintf('%d',Hours));
set(handles.editMinutes1, 'String', sprintf('%d',Minutes));
set(handles.editSeconds1, 'String', sprintf('%d',Seconds));
set(handles.editDSeconds1, 'String', sprintf('%d',DecSeconds));


handles = updateSegmentLimitsFromSliders(handles, windowPos);

[T1,T2] = getTimeFields(handles);

displaySignal(handles, T1, T2);

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function sliderT1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sliderT1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end




% --- Executes on slider movement.
function sliderWindow_Callback(hObject, eventdata, handles)
% hObject    handle to sliderWindow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

if (strcmp(handles.fileName,'')==1) return; end;

curPos = get(hObject,'Value');

TotalTimeTemp = curPos / 10 + handles.T1;

% check if slider has been moved out of bounds:
if (TotalTimeTemp > handles.fileTime)
    % set slider to previous value:
    set(hObject, 'Value', 10 * handles.Window);
    return;
end

handles.Window = curPos / 10;


handles = updateSegmentLimitsFromSliders(handles, curPos);

[T1,T2] = getTimeFields(handles);

displaySignal(handles, T1, T2);

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function sliderWindow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sliderWindow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editWindow_Callback(hObject, eventdata, handles)
% hObject    handle to editWindow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editWindow as text
%        str2double(get(hObject,'String')) returns contents of editWindow as a double


% --- Executes during object creation, after setting all properties.
function editWindow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editWindow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


function displaySignal(handles, T1, T2);

% This function plots the currently selected audio segment and the
% respective class labels (if any labels have been given)

%C1 = clock;

% Check T1 and Window values:

if (T1>=T2)  msgbox('Wrong segments limits.','Wrong limits','error'); return; end    
if (T1>handles.fileTime) msgbox('Wrong segments limits 1.','Wrong limits','error'); return; end    
if (T2>handles.fileTime) msgbox('Wrong segments limits 2.','Wrong limits','error'); return; end    


% read current window from .wav file:
flagsTemp = handles.flagsReal(round(T1*10)+1: round(T2*10));
x = wavread(handles.fileName, round([T1*handles.Fs+1 T2*handles.Fs]));
flagsTemp = imresize(flagsTemp, size(x));

% plot current audio signal:
set(handles.axesAudio,'Visible','on');
axes(handles.axesAudio);
time = [round(T1*handles.Fs)+1:round(T2*handles.Fs)] ./ handles.Fs;
plot(time, x);
axis([min(time) max(time) -1 1]);

TimeLimits = handles.limits / handles.Fs;

%C2 = clock;

% plot text ANNOTATION:

countSegments = 0;

% find all segments' limits that are between the selected Window:
Indexes = find(((TimeLimits(1,:) >= min(time)) & (((TimeLimits(1,:) <= max(time)))) ));

% for each segment limit in the current window:
for (i=1:length(Indexes))
    
        %a. if the 1st found LEFT boundary is more than 0.50 seconds from
        %   the begining of the window: write label:
        countSegments = countSegments + 1;
        
        if ((countSegments==1) && (TimeLimits(1,Indexes(i)) - min(time) > 0.50) && (Indexes(i)>1))            
            Pos = (TimeLimits(1,Indexes(i)) + min(time))/2;
            IndexClass = ((handles.labels(Indexes(i)-1)));            
            if (IndexClass>0)
                Text = text(Pos, 0.80, handles.classNames{IndexClass});        
            else
                Text = text(Pos, 0.80, 'UNCLASSIFIED');        
            end
            set(Text,'FontSize', 7);    
            TextPos = get(Text,'Extent'); TextLength = TextPos(3); 
            PosPrev = get(Text,'Position'); PosPrev(1) = PosPrev(1) - TextLength / 2; set(Text, 'Position', PosPrev);
        end
        
        
        % b. for the current label:
        L = line([TimeLimits(1,Indexes(i)) TimeLimits(1,Indexes(i))],[-1 1]);
        
        L1 = TimeLimits(1,Indexes(i));
        
        set(L,'color', [0.6 0.2 0.1]);
        if (((TimeLimits(2,Indexes(i)) <= max(time))))  % check for next segment:
            L2 = TimeLimits(2,Indexes(i));
        else
            L2 = max(time);
        end
                
        IndexClass = ((handles.labels(Indexes(i))));
        if (IndexClass>0)
            Text = text((L1+L2)/2, 0.80, handles.classNames{IndexClass});        
        else
            Text = text((L1+L2)/2, 0.80, 'UNCLASSIFIED');        
        end
        set(Text,'FontSize', 7);    
        TextPos = get(Text,'Extent'); TextLength = TextPos(3); 
        PosPrev = get(Text,'Position'); PosPrev(1) = PosPrev(1) - TextLength / 2; set(Text, 'Position', PosPrev);

    
end

% C3 = clock;

if (countSegments == 0) % if no segments have been drawn, i.e. if the current window length is not large enough to fit a segment
    % simply find in which segment the current window exists:
    WindowMiddle = (max(time) + min(time)) / 2;
    for (i=1:length(TimeLimits))            
        if ((WindowMiddle >= TimeLimits(1,i)) && (WindowMiddle <= TimeLimits(2,i)))
            curWindow = i;
        end
    end
    IndexClass = (handles.labels(curWindow));
    if (IndexClass>0)
        Text = text(WindowMiddle, 0.80, handles.classNames{IndexClass});        
    else
        Text = text(WindowMiddle, 0.80, 'UNCLASSIFIED');        
    end
    set(Text,'FontSize', 7);
end

%C4 = clock;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AXESFLAGS DISABLED SINCE 6/9/2007 (labels are since then displayed in the
% signal plotting area: axesAudio) %

%set(handles.axesFlags,'Visible','on');
%axes(handles.axesFlags);
%plot(time, flagsTemp);
%axis([min(time) max(time) -1 length(handles.classNames)]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% e1 = etime(C2,C1);
% e2 = etime(C3,C2);
% e3 = etime(C4,C3);
% fprintf('%.2f\t%.2f\t%.2f\n', e1, e2, e3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function handles = updateSegmentLimitsFromSliders(handles, curPos)

sec = (curPos / 10);
dsec = round(10*(sec-floor(sec)));
sec = floor(sec);
set(handles.editWindow, 'String', sprintf('%.2d.%d', sec, dsec));
[T1,T2, H1, M1, S1, DS1, H2, M2, S2, DS2] = getTimeFields(handles);

DS2 = DS1 + dsec;
tempS = 0;
if (DS2>=10)
    DS2 = DS2 - 10;
    tempS = 1;
end
S2 = S1 + sec + tempS;
tempM = 0;
if (S2>=60)
    S2 = S2 - 60;
    tempM = 1;
end
M2 = M1 + tempM;
tempH = 0;
if (M2>=60)
    M2 = M2 - 60;
    tempH = 1;
end
H2 = H1 + tempH;

set(handles.editHours2, 'String', sprintf('%d',H2));
set(handles.editMinutes2, 'String', sprintf('%d',M2));
set(handles.editSeconds2, 'String', sprintf('%d',S2));
set(handles.editDSeconds2, 'String', sprintf('%d',DS2));



% --- Executes during object creation, after setting all properties.
function sliderVolume_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sliderVolume (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end




% --- Executes on slider movement.
function slider5_Callback(hObject, eventdata, handles)
% hObject    handle to slider5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
handles.Volume = get(hObject,'Value');

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function slider5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


function plotHist(handles)
% this functions plots the histogram of the segmentation process:

set(handles.axesHist,'Visible','on');
axes(handles.axesHist);
H = zeros(length(handles.classNames)+1,1);
% find flags' histogram (including inclassified segments)
for (i=1:length(handles.flagsReal))
    H(handles.flagsReal(i) + 1) = H(handles.flagsReal(i) + 1) + 1;
end
H = 100 * H / sum(H);
Xaxis{1} = 'Unclassified';
for (i=1:length(handles.classNames)) Xaxis{i+1} = handles.classNames{i}; end;
bar(H);
axis([0 length(handles.classNames)+2 0 100]);

for (i=1:length(H))
    Text = text(i, H(i)+10, sprintf('%s: %.1f%%',Xaxis{i},H(i)));    
    set(Text,'FontSize', 7);    
    TextPos = get(Text,'Extent'); TextLength = TextPos(3); 
    PosPrev = get(Text,'Position'); PosPrev(1) = PosPrev(1) - TextLength / 2; set(Text, 'Position', PosPrev);
end
    
    


% --- Executes on button press in buttonSaveSegments.
function buttonSaveSegments_Callback(hObject, eventdata, handles)
% hObject    handle to buttonSaveSegments (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[numOfSegments, limits, labels] = writeToWavFile(handles.fileName, handles.flagsReal, 0.10, handles.classNames, 0);





% --- Executes on selection change in popupmenuFeature.
function popupmenuFeature_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuFeature (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenuFeature contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuFeature


% --- Executes during object creation, after setting all properties.
function popupmenuFeature_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuFeature (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popupmenuStatistic.
function popupmenuStatistic_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuStatistic (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenuStatistic contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuStatistic


% --- Executes during object creation, after setting all properties.
function popupmenuStatistic_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuStatistic (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end




% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

WIN = 0.020;
STEP = 0.020;
Features   = get(handles.popupmenuFeature, 'String');    
FeatureStr   = Features{get(handles.popupmenuFeature, 'Value')};
Statistics = get(handles.popupmenuStatistic, 'String');  
StatisticStr = Statistics{get(handles.popupmenuStatistic, 'Value')};
[T1,T2] = getTimeFields(handles);
x = wavread(handles.fileName, round([T1*handles.Fs+1 T2*handles.Fs]));

[FeatureSeq, FeatureStat] = parseFeatureExctraction(x, FeatureStr, 'max', WIN, STEP, handles.Fs);
LengthTime = (T2-T1);
StepTime = LengthTime / length(FeatureSeq);
time = T1:StepTime:T2;
time = time(1:end-1);

figure;
plot(time, FeatureSeq);
strTitle = [FeatureStr  ' Sequence'];
Text = text(min(time), max(FeatureSeq), sprintf('%s = %.5f', StatisticStr, FeatureStat));

title(strTitle);




