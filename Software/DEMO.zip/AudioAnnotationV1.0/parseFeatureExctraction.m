function [FeatureSeq, FeatureStat] = parseFeatureExctraction(signal, FeatureStr, StatisticStr, win, step, Fs)

% function [FeatureSeq, FeatureStat] = parseFeatureExctraction(signal, FeatureStr, StatisticStr, win, step)
%
% This function computes the feature sequence and feature statistic (value)
% of an audio signal. It is actually a parser of all feature functions
% available.
% 
% ARGUMENTS:
% signal:        the signal values
% FeatureStr:    the string of the feature name (and respective function)
% StatisticStr:  the feature statistic name (as used in Statistic.m)
% win:           the window length (in seconds)
% step:          the window step (in seconds)
% Fs:            the sampling freq.
% 
% RETURN VALUES:
% FearureSeq:    The feature sequence
% FeatureStat:   The featre statistic value


% Create command for feature extraction:
strCom = sprintf('FeatureSeq = %s(signal, win*Fs, win*Fs, Fs);', FeatureStr);

% Run command for feature extraction:
eval(strCom);

% Find statistic:
FeatureStat = statistic(FeatureSeq, 1, length(FeatureSeq), StatisticStr);


