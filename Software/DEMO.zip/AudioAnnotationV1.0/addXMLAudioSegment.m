function addXMLAudioSegment(xmlName, T1, T2, label)

xDoc = xmlread(xmlName);

xRoot = xDoc.getDocumentElement;

allTemporal = xDoc.getElementsByTagName('TemporalDecomposition');

TemporalDecomposition = allTemporal.item(0);

    AudioSegment  = xDoc.createElement('AudioSegment');
    TextAnnotation  = xDoc.createElement('TextAnnotation');
    FreeTextAnnotation  = xDoc.createElement('FreeTextAnnotation');
    MediaTime2  = xDoc.createElement('MediaTime');
    MediaTimePoint2 = xDoc.createElement('MediaTimePoint');
    MediaDuration2 = xDoc.createElement('MediaDuration');
           
    
    MediaTimePoint2.appendChild(xDoc.createTextNode(sprintf('%.1f',T1)));
    MediaDuration2.appendChild(xDoc.createTextNode(sprintf('%.1f',T2-T1)));
    FreeTextAnnotation.appendChild(xDoc.createTextNode(sprintf('%s',label)));


    % put nodes in the correct positions..
	
      TemporalDecomposition.appendChild(AudioSegment);
      AudioSegment.appendChild(TextAnnotation);
        TextAnnotation.appendChild(FreeTextAnnotation);
      AudioSegment.appendChild(MediaTime2);
      MediaTime2.appendChild(MediaTimePoint2);
      MediaTime2.appendChild(MediaDuration2);


xmlwrite(xmlName, xDoc);